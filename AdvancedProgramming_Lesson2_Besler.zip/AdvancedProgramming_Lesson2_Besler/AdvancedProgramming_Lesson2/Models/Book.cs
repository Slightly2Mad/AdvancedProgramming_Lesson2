﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdvancedProgramming_Lab1_Besler_21a.Models
{
    public class Book
    {
        [Display(Name = "Identyfikator")]
        public int Id { get; set; }

        [Display(Name = "Tytuł")]
        public string Title { get; set; }

        [Display(Name = "Przeczytano")]

        [DataType(DataType.Date)]
        public DateTime ReadDate { get; set; }

        [Display(Name = "Autor")]
        public string Author { get; set; }

        [Display(Name = "Moja ocena")]

        [Range(0, 5)]
        public int Rating { get; set; }
    }
}
